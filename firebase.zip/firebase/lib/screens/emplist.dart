import 'package:flutter/material.dart';

class EmpList extends StatefulWidget {
  @override
  _EmpListState createState() => _EmpListState();
}

class _EmpListState extends State<EmpList> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Employee List'),
      ),
    );
  }
}
